# Instructions

Get python client
	
	wget https://raw.githubusercontent.com/nicehash/rest-clients-demo/master/python/nicehash.py
	
Install dependencies
	
	pip install requests
	
Enter API key/secret/org in to the bash script

    ./run.sh
    
For more options see

    python nicehash.py  -h
