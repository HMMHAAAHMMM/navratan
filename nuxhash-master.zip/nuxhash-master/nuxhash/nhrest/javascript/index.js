require = require("esm")(module/*, options*/);

// examples
//require("./hashpower");
//require("./exchange");
