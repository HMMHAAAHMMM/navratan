### NODE API

- Install dependencies

	npm install
	
- Enter your API key settings into config.js
- Uncomment example you want to run in index.js
- Run with

	node index.js
