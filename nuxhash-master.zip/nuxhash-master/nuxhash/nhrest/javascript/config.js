export default {
	apiHost: 'https://api-test.nicehash.com', //use https://api2.nicehash.com for production
	apiKey: 'xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx', //get it here: https://test.nicehash.com/my/settings/keys or https://new.nicehash.com/my/settings/keys
	apiSecret: 'xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxxxxxxxxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx',
	orgId: 'xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx',
}
