def nuxhashd():
    from nuxhash.daemon import main
    main()

def nuxhash_gui():
    from nuxhash.gui.main import main
    main()
