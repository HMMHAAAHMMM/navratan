__version__ = '1.0.0b2'
__copyright__ = 'Copyright © 2018-2019\nRyan Young'
