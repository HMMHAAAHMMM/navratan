from nuxhash.miners.excavator import Excavator


all_miners = [Excavator]

